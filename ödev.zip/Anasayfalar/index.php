/****************************************************************************
**					SAKARYA �N�VERS�TES�
**				B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				    B�LG�SAYAR M�HEND�SL��� B�L�M�
**				   NESNEYE DAYALI PROGRAMLAMA DERS�
**					2023-2024 BAHAR D�NEM�
**	
**				�DEV NUMARASI......1....:
**				��RENC� ADI.......Bora K�seler .....:
**				��RENC� NUMARASI.....B231210060..:
**                         DERS�N ALINDI�I GRUP...:
****************************************************************************/


<?php
    include("connection.php")
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta http-equiv="Content-Type" content="text/html charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div id="form">
        <h1>Login form</h1>
        <form name="form" action="login.php" onsubmit ="return isvalid()" method="POST">
            <label>Username:</label>
            <input type="text" id="user" name="user"></br></br>
            <label>Password:</label>
            <input type="password" id="pass" name="pass"></br></br>
            <input type="submit" id="btn" value="Login" name="submit"/>
        </form>
    </div>
    <script>
        function isvalid()
        {
            var user = document.form.user.value;
            var pass = document.form.pass.value;
            if(user.length =="" && pass.length=="")
            {
                alert("Username and password field is empty!!!");
                return false
            }
            else
            {
                if(user.length =="")
                {
                    alert("Username is empty");
                    return false
                }
                if(pass.length =="")
                {
                    alert("Password is empty");
                    return false
                }
            }
        }
    </script>
</body>
</html>