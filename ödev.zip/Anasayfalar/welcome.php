<?php
    header('Refresh:2; Anasayfa.html');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="Window 1254">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1 style="text-align: center; ">Hosgeldiniz B231210060</h1> 
</body> 
</html>
